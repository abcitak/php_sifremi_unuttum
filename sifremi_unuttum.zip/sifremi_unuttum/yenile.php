<?php 
require 'baglan.php';

if(!$_GET['hash'] || empty($_GET['hash'])){
    header('Location:login.php');
    exit;
}else{

$sql = $db->prepare('SELECT * FROM eposta');
$sql->execute();
$getir = $sql->fetch(PDO::FETCH_ASSOC);

    if(isset($_POST['btn_yenile'])){
    $yeni_sifre = sha1($_POST['sifre']);
    $sorgu = $db->prepare('UPDATE eposta SET sifre = ? WHERE dogrulama_kodu = ?');
    $update = $sorgu->execute([$yeni_sifre,$getir['dogrulama_kodu']]);
    if($update){
        echo '<script>alert("Şifreniz Başarılıyla Değiştirildi.");</script>';
        
    }else{
          echo '<script>alert("Bir Sorun Oluştu");</script>';
    }
  }
}

 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<meta charset="utf-8">
 </head>
 <body>
 <form method="POST">
 <label>Yeni Şifre Giriniz : </label><input type="password" name="sifre">
 <button type="submit" name="btn_yenile">Yenile</button>
 </form>
 </body>
 </html>