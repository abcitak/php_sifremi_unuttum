<?php 
require 'baglan.php';

if(isset($_POST['btn_unuttum'])){
	$eposta = $_POST['eposta'];

	$sorgu = $db->prepare('SELECT * FROM eposta');
	$sorgu->execute();
	$sec = $sorgu->fetch(PDO::FETCH_ASSOC);

	if($sec['eposta'] == $eposta){
		$hash = sha1(uniqid());
		$sorgu = $db->prepare('UPDATE eposta SET dogrulama_kodu = ? WHERE eposta = ?');
		$dogrula = $sorgu->execute([$hash,$eposta]);
		if($dogrula){
			$link = '<a href="http://localhost/yenile.php?hash='.$hash.'">Şifreyi Yenilemek İçin Tıklayınız!</a>';
			echo $link;
		}

	}else{
		echo 'E-Posta Adresi Bulunamadı';
	}

}


 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<meta charset="utf-8">
 </head>
 <body>
 <form method="POST">
 	<label>Eposta Adresini Giriniz</label>
 	<input type="text" name="eposta" placeholder="E-Posta Adresiniz">
 	<button type="submit" name="btn_unuttum">Şifremi Unuttum</button>
 </form>
 </body>
 </html>